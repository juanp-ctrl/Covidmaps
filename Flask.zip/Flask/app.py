from flask import Flask, render_template, url_for, request, redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'
db = SQLAlchemy(app)


class Lista(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    contenido = db.Column(db.String(200), nullable=False)
    completado = db.Column(db.Integer, default=0)
    date_created = db.Column(db.DateTime, default = datetime.utcnow)

    def __repr__(self):
        return '<Task %r>' % self.id

@app.route('/', methods=['POST', 'GET'])
def index():

    if request.method == 'POST':
        Ncontenido = request.form['nombre']
        nuevo_registro = Lista(contenido = Ncontenido)

        try:
            db.session.add(nuevo_registro)
            db.session.commit()
            return redirect('/')
        except:
            return 'Error al registrar'

    else:
        tasks = Lista.query.order_by(Lista.date_created).all()
        return render_template('index.html', tasks= tasks) 

@app.route('/borrar/<int:id>')
def borrar(id):
    registro_borrar = Lista.query.get_or_404(id)

    try:
        db.session.delete(registro_borrar)
        db.session.commit()
        return redirect('/')
    except:
        return 'Error al eliminar el registro'

@app.route('/actualizar/<int:id>', methods=['GET', 'POST'])
def actualizar(id):
    task = Lista.query.get_or_404(id)
    if request.method == 'POST':
        task.contenido = request.form['nombre']

        try:
            db.session.commit()
            return redirect('/')
        except:
            return 'Error al actualizar'
    else:
        return render_template('actualizar.html', task=task)


if __name__ == "__main__":
    app.run(debug=True)